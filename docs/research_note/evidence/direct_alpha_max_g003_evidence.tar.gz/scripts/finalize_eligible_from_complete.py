#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

REPO = Path("/home/hoky/Quants-agent/LuminaQuant")
RUN = Path("/home/hoky/quants-direct-alpha-max/g003-338e7b38f48e06951d6552f4943101b4")
OUTPUT = RUN / "source"
REPORT = RUN / "report"
CONTRACT = Path(
    "/home/hoky/quants-recovery-runs/G056-full-acquisition-controller-20260719-v3/contract.json"
)
EVIDENCE = Path(
    "/home/hoky/quants-recovery-runs/G056-full-acquisition-controller-20260719-v3/availability-evidence.json"
)
EXPECTED_CODE_SHA256 = "6e0b7115532e1bd8632df28f6f5426aff8ca4e0dead130a682600c812f9da76d"

sys.path.insert(0, str(REPO))
from scripts.research import acquire_alpha_max_official_source as acquisition  # noqa: E402


def main() -> int:
    if acquisition.file_sha256(Path(acquisition.__file__)) != EXPECTED_CODE_SHA256:
        raise RuntimeError("frozen acquirer changed")
    if hashlib.sha256(CONTRACT.read_bytes()).hexdigest() != acquisition.CONTRACT_SHA256:
        raise RuntimeError("contract changed")
    if hashlib.sha256(EVIDENCE.read_bytes()).hexdigest() != acquisition.EVIDENCE_SHA256:
        raise RuntimeError("availability evidence changed")
    contracts = acquisition.load_contract(CONTRACT)
    acquisition.load_evidence(EVIDENCE)
    eligible = REPORT / "source_eligible_receipt.json"
    with acquisition.owned_run_lock(REPORT, exclusive=True):
        acquisition.verify_ownership(
            OUTPUT, REPORT, acquisition.sha256(acquisition.canonical_bytes(acquisition.full_plan()))
        )
        if eligible.exists():
            raise RuntimeError("eligible receipt already exists")
        acquisition.rebuild_manifest(OUTPUT, REPORT)
        receipt = acquisition.validate_complete(
            OUTPUT, contracts, REPORT / "provenance", REPORT
        )
        receipt["source_manifest_sha256"] = acquisition.file_sha256(
            REPORT / "source_manifest.json"
        )
        receipt["acquisition_journal_sha256"] = acquisition.file_sha256(
            REPORT / "acquisition.journal.jsonl"
        )
        acquisition.verify_ownership(
            OUTPUT, REPORT, acquisition.sha256(acquisition.canonical_bytes(acquisition.full_plan()))
        )
        acquisition.immutable_json(eligible, receipt, REPORT)
    print(
        json.dumps(
            {
                "eligible_receipt": str(eligible),
                "eligible_sha256": acquisition.file_sha256(eligible),
                "raw_rows": receipt["raw_rows"],
                "funding_rows": receipt["funding_rows"],
                "source_eligible": receipt["source_eligible"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
